/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigdatasquad;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Map;

/**
 *
 * @author asus
 */
public class Export_csv {
     public static String[][] export_csv(Hashtable<String, float []> res,String csv_file) throws FileNotFoundException {
     try (PrintWriter writer = new PrintWriter(new File(csv_file))) {
     StringBuilder builder = new StringBuilder();
     builder.append("Group Name");
     builder.append(",");
     builder.append("Count");
     builder.append(",");
     builder.append("Average");
     builder.append(",");
     builder.append("Minimum");
     builder.append(",");
     builder.append("Maximum");
     builder.append(",");
     builder.append("Sum");
     builder.append("\r\n");
     for (Map.Entry<String, float []> kvp : res.entrySet()) {
             builder.append(kvp.getKey());
             builder.append(",");
             builder.append((int)(kvp.getValue()[0]));
             builder.append(",");
             builder.append(kvp.getValue()[1]);
             builder.append(",");
             builder.append(kvp.getValue()[2]);
             builder.append(",");
             builder.append(kvp.getValue()[3]);
             builder.append(",");
             builder.append(kvp.getValue()[4]);
             builder.append("\r\n");
}
     
     String content = builder.toString().trim();
     writer.write(builder.toString());
     System.out.println(content);
    
}
       return null;
}
   
}